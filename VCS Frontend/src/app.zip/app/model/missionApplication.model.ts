export class MissionApplication{
  id:number=0;
  missionTitle:string='';
  missionId:number=0;
  userId:any;
  userName:string='';
  appliedDate:any;
  sheet:number=0;
  status:any;
}
